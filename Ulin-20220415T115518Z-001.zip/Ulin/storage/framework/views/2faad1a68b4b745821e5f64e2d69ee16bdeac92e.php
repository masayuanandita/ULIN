<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <button class="btn btn-info">Tes Button</button>
</body>
</html><?php /**PATH C:\Kuliah\SMSTR 6\Praktikum\TUBES ABP\Ulin\resources\views/button.blade.php ENDPATH**/ ?>